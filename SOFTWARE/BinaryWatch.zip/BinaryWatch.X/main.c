/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

#if defined(__XC)
    #include <xc.h>         /* XC8 General Include File */
#elif defined(HI_TECH_C)
    #include <htc.h>        /* HiTech General Include File */
#endif

#include <stdint.h>        /* For uint8_t definition */
#include <stdbool.h>       /* For true/false definition */

#include "system.h"        /* System funct/params, like osc/peripheral config */
#include "user.h"          /* User funct/params, such as InitApp */

/******************************************************************************/
/* User Global Variable Declaration                                           */
/******************************************************************************/

/**
 * Define months length
 * 
 * @Note: February is 28 days. Since the clock doesn't support year, there is
 * no ways of determine if February is 28 or 29 days.
 */
uint8_t months_length[12] = {
    31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
};

/**
 * Setup the clock
 * 
 * Make initial configuration 00:00:00, 1 January 
 */
struct clock clock = {
    {0, 0, 0}, {1, 1},
};

enum state current_state = STATE_SETUP;	/* On power-up setup the clock */

/******************************************************************************/
/* Main Program                                                               */
/******************************************************************************/
void main(void)
{
    /* Configure the oscillator for the device */
    ConfigureOscillator();

    /* Initialize I/O and Peripherals for application */
    InitApp();

    while(1) {
        switch (current_state) {
            case STATE_RUNNING:
                asm("SLEEP");
                break;
            
            case STATE_SETUP:
                SetupClock();
                current_state = STATE_RUNNING;
                break;
            
            default:
                break;
        }        
    }
}


