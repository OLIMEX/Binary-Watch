/******************************************************************************/
/*Files to Include                                                            */
/******************************************************************************/

#if defined(__XC)
#include <xc.h>         /* XC8 General Include File */
#elif defined(HI_TECH_C)
#include <htc.h>        /* HiTech General Include File */
#endif

#include <stdint.h>         /* For uint8_t definition */
#include <stdbool.h>        /* For true/false definition */
#include "user.h"

/******************************************************************************/
/* Interrupt Routines                                                         */
/******************************************************************************/

/* Baseline devices don't have interrupts. Note that some PIC16's 
 * are baseline devices.  Unfortunately the baseline detection macro is 
 * _PIC12 */
#ifndef _PIC12

void interrupt isr(void) {

	if (PIR1bits.TMR1IF) {

		if (++clock.time.seconds > 59) {
			clock.time.seconds = 0;

			if (++clock.time.minutes > 59) {
				clock.time.minutes = 0;

				if (++clock.time.hours > 23) {
					clock.time.hours = 0;

					if (++clock.date.day > months_length[clock.date.month - 1]) {
						clock.date.day = 1;

						if (++clock.date.month > 12) {
							clock.date.month = 1;
						}
					}
				}
			}
		}
		TMR1H |= 0x80; // preset for timer1 MSB register
		//	TMR1L = 0x00;

		if (!PORTBbits.RB0 && PORTBbits.RB1)
            ShowClock();
		else if (!PORTBbits.RB1 && PORTBbits.RB0)
			ShowDate();
		PIR1bits.TMR1IF = 0;

	} else if (INTCONbits.RBIF) {

		/* Check if button1 is pressed */
		if (!PORTBbits.RB0 && PORTBbits.RB1)
            ShowClock();
		else if (PORTBbits.RB0 && !PORTBbits.RB1)
            ShowDate();
		else if (!PORTBbits.RB0 && !PORTBbits.RB1)
			current_state = STATE_SETUP;
		else {
            HideClock();
            HideDate();
        }

		INTCONbits.RBIF = 0;
	}
}
#endif


