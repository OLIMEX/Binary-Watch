/******************************************************************************/
/* User Level #define Macros                                                  */
/******************************************************************************/

#define TIME_PORT	PORTBbits.RB0
#define DATE_PORT	PORTBbits.RB1

/******************************************************************************/
/* User Function Prototypes                                                   */
/******************************************************************************/

struct time {
	uint8_t seconds;
	uint8_t minutes;
	uint8_t hours;
};

struct date {
	uint8_t day;
	uint8_t month;
};

struct clock {
    struct time time;
    struct date date;
};

enum state {
	STATE_RUNNING = 0,
	STATE_SETUP,
};

extern uint8_t months_length[12];
extern enum state current_state;
extern struct clock clock;

void InitApp(void);
void InitTimer1(void);

void ShowClock(void);
void HideClock(void);

void ShowDate(void);
void HideDate(void);

void SetupClock(void);
void PlayAnimation(void);