/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/
#if defined(__XC)
    #include <xc.h>         /* XC8 General Include File */
#elif defined(HI_TECH_C)
    #include <htc.h>        /* HiTech General Include File */
#endif

#include <stdint.h>         /* For uint8_t definition */
#include <stdbool.h>        /* For true/false definition */

#include "system.h"
#include "user.h"

/******************************************************************************/
/* User Functions                                                             */
/******************************************************************************/

void InitApp(void)
{
	/* Setup analog functionality and port direction */
	ANSELA = 0;
	ANSELB = 0;

	/* Initialize PORTA */
	TRISA = 0x00;
	PORTA = 0x00;

	/* Initialize PORTB */
	TRISB = 0x00;
	PORTB = 0x00;
	
	TRISBbits.TRISB0 = 1;	/* Make Button1 as input */
	TRISBbits.TRISB1 = 1;	/* Make Button2 as input */

	OPTION_REGbits.nRBPU = 0;	/* Enable weak-pullups */
	WPUBbits.WPUB0 = 1;		/* Enable WPU for button1 */
	WPUBbits.WPUB1 = 1;		/* Enable WPU for button2 */

	IOCBbits.IOCB0 = 1;
	IOCBbits.IOCB1 = 1;

	TRISC = 0x00;
	PORTC = 0x00;

    /* Initialize peripherals */
	InitTimer1();

    /* Enable interrupts */
	INTCONbits.RBIF = 0;	/* Clear any pending interrupt */
	INTCONbits.RBIE = 1;	/* Enable Interrupt-On-Change on PORTB */

	PIR1bits.TMR1IF = 0;	/* Clear any pending interrupt */
	PIE1bits.TMR1IE = 1;	/* Enable interrupt on overflow */
	
	INTCONbits.PEIE = 1;	/* Enable peripheral interrupts */
	INTCONbits.GIE = 1;		/* Enable general interrupts */
}


void InitTimer1(void)
{
	T1CONbits.T1OSCEN = 1;		/* Enable dedicated oscillator */
	T1CONbits.nT1SYNC = 1;		/* Running in ASYNC mode */
	T1CONbits.TMR1CS = 0x02;	/* Select oscillator as clock source */
	T1GCONbits.TMR1GE = 0;		/* Disable Gate Control */

	TMR1H = 0x80;
	TMR1L = 0x00;

	T1CONbits.TMR1ON = 1;		/* Enable Timer1 */
    
    /**
     * Wait for TMR1 interrupt.
     * This way proper crystal operation can be verified.
     */
    
    PIR1bits.TMR1IF = 0;    
    while (!PIR1bits.TMR1IF);
    INTCONbits.TMR0IF = 0;
}

static uint8_t ReverseMinutes(uint8_t byte)
{
	uint8_t temp = 0;

	temp |= (byte & 0x20) ? 0x01 : 0x00;
	temp |= (byte & 0x10) ? 0x02 : 0x00;
	temp |= (byte & 0x08) ? 0x04 : 0x00;
	temp |= (byte & 0x04) ? 0x08 : 0x00;
	temp |= (byte & 0x02) ? 0x10 : 0x00;
	temp |= (byte & 0x01) ? 0x20 : 0x00;

	return temp;
}

static uint8_t ReverseHours(uint8_t byte)
{
	uint8_t temp = 0;

	temp |= (byte & 0x10) ? 0x01 : 0x00;
	temp |= (byte & 0x08) ? 0x02 : 0x00;
	temp |= (byte & 0x04) ? 0x04 : 0x00;
	temp |= (byte & 0x02) ? 0x08 : 0x00;
	temp |= (byte & 0x01) ? 0x10 : 0x00;

	return temp;
}

void ShowClock(void)
{
	PORTA = ReverseMinutes(clock.time.minutes);
	PORTC = ReverseHours(clock.time.hours) << 3;
}

void HideClock(void)
{
	PORTA &= ~(0x3F);
	PORTC &= ~(0x1F << 3);
}

void ShowDate(void)
{
	PORTA = ReverseMinutes(clock.date.day);
	PORTC = ReverseHours(clock.date.month) << 3;
}

void HideDate(void)
{
	PORTA &= ~(0x3F);
	PORTC &= ~(0x1F << 3);
}

void PlayAnimation(void)
{
    uint8_t i;
    
	HideClock();
	__delay_ms(50);

	
	for (i = 0; i < 6; i++) {
		PORTA |= 0x01 << (5-i);
		__delay_ms(50);
	}
	for (i = 0; i < 6; i++) {
		PORTA &= ~(0x01 << (5-i));
		__delay_ms(50);
	}

	for (i = 3; i < 9; i++) {
		PORTC |= (0x01 << (11-i));
		__delay_ms(50);
	}
	for (i = 3; i < 9; i++) {
		PORTC &= ~(0x01 << (11-i));
		__delay_ms(50);
	}
}

void SetupClock(void)
{
    uint8_t i;

	INTCONbits.GIE = 0;
	PlayAnimation();

	/* Wait both buttons to be released */
	while (!TIME_PORT || !DATE_PORT);

	/* Setup minutes */
	for (i = 0; i < 6; i++) {
		
		ShowClock();
		
		/* Blink current segment */
		while (1) {
			PORTA ^= 0x01 << (5-i);
			__delay_ms(100);


			/* Wait for button press */
			if (INTCONbits.RBIF) {
				__delay_ms(10);
				
				/* Detect button press */
				if (!TIME_PORT && DATE_PORT) {
					/* Toggle current bit */
					uint8_t current_bit = !!(clock.time.minutes & ( 0x01 << i));

					current_bit ^= 1;

					PORTA &= ~(0x01 << (5-i));
					PORTA |= current_bit << (5-i);

					clock.time.minutes = ReverseMinutes(PORTA & 0x3F);

					/* Wait button to be released */
					__delay_ms(10);
					while (!TIME_PORT);
				} else if (TIME_PORT  && !DATE_PORT) {
					ShowClock();
					while (!DATE_PORT) {
						__delay_ms(10);

						if (!TIME_PORT && !DATE_PORT) {
							goto EXIT;
						}
					}
					break;
				}
			}
		}
	}

	/* Setup hours */
	for (i = 0; i < 5; i++) {
		ShowClock();

		/* Blink current segment */
		while (1) {
			PORTC ^= 0x01 << (7-i);
			__delay_ms(100);

			/* Wait for button press */
			if (INTCONbits.RBIF) {
				__delay_ms(10);

				/* Detect button press */
				if (!TIME_PORT && DATE_PORT) {
					/* Toggle current bit */
					uint8_t current_bit = !!(clock.time.hours & ( 0x01 << i));

					current_bit ^= 1;

					PORTC &= ~(0x01 << (7-i));
					PORTC |= current_bit << (7-i);

					clock.time.hours = ReverseHours(PORTC >> 3);

					/* Wait button to be released */
					__delay_ms(10);
					while (!TIME_PORT);
				} else if (TIME_PORT  && !DATE_PORT) {
					ShowClock();
					while (!DATE_PORT) {
						__delay_ms(10);

						if (!TIME_PORT && !DATE_PORT) {
							goto EXIT;
						}
					}
					break;
				}
			}
		}
	}

	PlayAnimation();
	__delay_ms(100);


	/* Setup month */
	for (i = 0; i < 4; i++) {

		ShowDate();

		/* Blink current segment */
		while (1) {
			PORTC ^= 0x01 << (7-i);
			__delay_ms(100);


			/* Wait for button press */
			if (INTCONbits.RBIF) {
				__delay_ms(10);

				/* Detect button press */
				if (!TIME_PORT && DATE_PORT) {
					/* Toggle current bit */
					uint8_t current_bit = !!(clock.date.month & ( 0x01 << i));

					current_bit ^= 1;

					PORTC &= ~(0x01 << (7-i));
					PORTC |= current_bit << (7-i);

					clock.date.month = ReverseHours(PORTC >> 3);

					/* Wait button to be released */
					__delay_ms(10);
					while (!TIME_PORT);
				} else if (TIME_PORT  && !DATE_PORT) {
					ShowDate();
					while (!DATE_PORT) {
						__delay_ms(10);

						if (!TIME_PORT && !DATE_PORT) {
							goto EXIT;
						}
					}
					break;
				}
			}
		}
	}

	/* Setup date */
	for(i = 0; i < 5; i++){

		ShowDate();

		/* Blink current segment */
		while (1) {
			PORTA ^= 0x01 << (5-i);
			__delay_ms(100);

			/* Wait for button press */
			if (INTCONbits.RBIF) {
				__delay_ms(10);

				/* Detect button press */
				if (!TIME_PORT && DATE_PORT) {
					/* Toggle current bit */
					uint8_t current_bit = !!(clock.date.day & ( 0x01 << i));

					current_bit ^= 1;

					PORTA &= ~(0x01 << (5-i));
					PORTA |= current_bit << (5-i);

					clock.date.day = ReverseMinutes(PORTA & 0x3F);

					/* Wait button to be released */
					__delay_ms(10);
					while (!TIME_PORT);
				} else if (TIME_PORT  && !DATE_PORT) {
					ShowDate();
					while (!DATE_PORT) {
						__delay_ms(10);

						if (!TIME_PORT && !DATE_PORT) {
							goto EXIT;
						}
					}
					break;
				}
			}
		}
	}

EXIT:
	/* Check if minutes is correct */
	if (clock.time.minutes > 59)
		clock.time.minutes = 0;

	/* Check if hours are correct */
	if (clock.time.hours > 23)
		clock.time.hours = 0;

	clock.time.seconds = 0;
	T1CONbits.TMR1ON = 1;

	/* Check if month is correct */
	if (clock.date.month > 12 || clock.date.month < 1)
		clock.date.month = 1;

	/* Check if date is correct */
	if (clock.date.day > months_length[clock.date.month - 1] || clock.date.day < 1)
		clock.date.day = 1;

	PlayAnimation();
	__delay_ms(200);

	INTCONbits.GIE = 1;
}

